RPLIDAR Public SDK v1.9.0 Release Note
======================================

- [new feature] support HQ scan response
