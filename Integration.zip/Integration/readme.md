To run tests please use the following command:
`PYTHONPATH=. pytest -v`
